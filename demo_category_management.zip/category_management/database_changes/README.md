Steps to Run Project

1.Import SQL file path- database_changes/category_management.sql
    category_management.sql

2. Update database connection setting from .env
        DB_CONNECTION=mysql
        DB_HOST=172.16.0.182
        DB_PORT=3306
        DB_DATABASE=category_mgt
        DB_USERNAME=root
        DB_PASSWORD=m/RlxUJMhQW3

3.Run Project using-
    localhost/category_management/public/category