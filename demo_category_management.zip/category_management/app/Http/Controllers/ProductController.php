<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;

class ProductController extends Controller
{
    public function show($id)

    {
        $subcategories = Category::where('categories.id', $id)
                ->join('products', 'products.category_id', '=', 'categories.id')       
                ->select('products.*','categories.name as category_name')->get();
        return response($subcategories);

    }
}
