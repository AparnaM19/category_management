<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use App\Product;
use Illuminate\Support\Facades\Validator;

class CategoryController extends Controller
{
        /**

     * Display a listing of the resource.

     *

     * @return \Illuminate\Http\Response

     */

    public function index()

    {

        $categories = Category::latest()->paginate(5);  

        return view('index',compact('categories'))
            ->with('i', (request()->input('page', 1) - 1) * 5);

    }
//   

   

    /**

     * Show the form for creating a new resource.

     *

     * @return \Illuminate\Http\Response

     */

    public function create()

    {

        return view('create');

    }

  

    /**

     * Store a newly created resource in storage.

     *

     * @param  \Illuminate\Http\Request  $request

     * @return \Illuminate\Http\Response

     */

    public function store(Request $request)

    {

        $validator = Validator::make($request->all(), [
            'name' => 'required|unique:categories,name',
            'sub_cat_name' => 'required|unique:products,sub_cat_name',
            'sub_cat_info' => 'required',
        ]);
        if ($validator->passes())
        {
            $category = Category::create([
                'name' => $request->name,
                ]);

            Product::create([
                'category_id' => $category->id,
                'sub_cat_name' => $request->sub_cat_name,
                'sub_cat_info' => $request->sub_cat_info
            ]);
            return response()->json(['success'=>'Product created successfully.']);
        }
        return response()->json(['error'=>$validator->errors()->all()]);
    }

   

    /**

     * Display the specified resource.

     *

     * @param  \App\Product  $product

     * @return \Illuminate\Http\Response

     */

    public function show(Product $product)

    {

        return view('products.show',compact('product'));

    }

   


}
