<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    //
    protected $fillable = ['category_id','sub_cat_name','sub_cat_info']; 
    public function category(){
        return $this->belongsTo(Category::class);
    }
}
