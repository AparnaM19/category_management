@extends('layout') 

@section('content')
    <br>
    <br>
    <br>
    <br>
    <div class="row">

        <div class="col-lg-12 margin-tb">

            <div class="pull-left">

<!--                <h2>Category Management</h2>-->

            </div>
            <div class="pull-right">
                <button class="btn btn-success btn-lg" data-toggle="modal" data-target="#modalForm">
                    Create New Category
                </button>
            </div>
        </div>
    </div>
    <br>
   

    @if ($message = Session::get('success'))

        <div class="alert alert-success">

            <p>{{ $message }}</p>

        </div>

    @endif

   

    <table class="table table-bordered">

        <tr>
            <th>Index</th>
            <th>Name</th>
<!--            <th>Image</th>-->
            <th width="280px">Subcategories</th>
        </tr>
        @if(count($categories)>0)
        @foreach ($categories as $category)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $category->name }}</td>
            <td>
                <a class="btn btn-info" ng-click="showCategoryDetails({{$category->id}})">View</a>               
            </td>
        </tr>
        @endforeach
        @else
         <tr>
             <td colspan="3">No Data Found </td>
        </tr>
        @endif
    </table>
      {{ $categories->links() }}

    
    
<!-- Add Category Modal Start -->
<div class="modal fade" id="modalForm" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                    <span class="sr-only">Close</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">Category Form</h4>
            </div>
            
            <!-- Modal Body -->
            <div class="modal-body">
                <p class="text-success statusMsg"></p>
                <div class="alert alert-danger" ng-if="errors.length > 0">
                    <ul>
                        <li ng-repeat="error in errors">@{{ error }}</li>
                    </ul>
                </div>
                <form name="CategoryForm" ng-submit="submitForm(category)" novalidate enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="inputName">Add Category</label>
                        <input type="text" class="form-control" id="name" name="name" ng-model="category.name" placeholder="Enter category name" required=""/>
                        <p ng-show="submitted && CategoryForm.name.$error.required" class="text-danger">Category Name is required</p>
                    </div>
<!--                    <div class="form-group">
                        <label for="inputName" >Add Category Image</label>
                        <input type="file"  name="image" id="image" ng-model="category.image"/>
                    </div>-->
                    <div class="form-group">
                        <label for="inputName">Sub Category Name</label>
                        <input type="text" class="form-control" id="sub_cat_name" ng-model="category.sub_cat_name" name="sub_cat_name" placeholder="Enter sub-category name" required=""/>
                        <p ng-show="submitted && CategoryForm.sub_cat_name.$error.required" class="text-danger">Sub-category Name is required</p>
                    </div>
                    <div class="form-group">
                        <label for="inputEmail">Sub Category Info</label>
                        <textarea  rows="3" id="sub_cat_info" class="form-control" ng-model="category.sub_cat_info" name="sub_cat_info" placeholder="Enter sub-category information" required=""></textarea>
                        <p ng-show="submitted && CategoryForm.sub_cat_info.$error.required" class="text-danger">Sub-category Info is required</p>
                    </div>
                    
                    <!-- Modal Footer -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Submit</button>                             
                    </div>
                </form>
            </div>
            
            
        </div>
    </div>
</div>
<!-- Add Category Modal End -->

<!-- View Sub - Categories Modal Start -->
<div class="modal fade" id="SubCategorymodalForm" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                    <span class="sr-only">Close</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">Subcategories <span ng-if='subcategories.length>0'>of @{{subcategories[0].category_name}}</span></h4>
            </div>
            
            <!-- Modal Body -->
            <div class="modal-body">
                <p class="text-success statusMsg"></p>
              
                    <dl ng-repeat="subcategory in subcategories">
                        <dt>@{{ subcategory.sub_cat_name }}</dt>
                        <dd>@{{ subcategory.sub_cat_info }}</dd>
                    </dl>
                <div>
                    <ul>
                        <span ng-if='subcategories.length==0'>No Sub-category Found</span>
                    </ul>
                </div>
            </div>
            
            
        </div>
    </div>
</div>
<!-- Add Category Modal End -->

<script>
    var url = '<?php echo asset('/'); ?>';
    // create angular app
var CategoryMgtApp = angular.module('CategoryMgtApp', []);
// create angular controller
CategoryMgtApp.controller('mainController', function($scope,$http,$timeout) {
    
// function to submit the form after all validation has occurred			
$scope.submitForm = function(isValid) {
   
// check to make sure the form is completely valid
if ($scope.CategoryForm.$valid) { 
    $http.post(url+'category', $scope.category).then(function success(e) {
        if(e.data.success) {
            $(".statusMsg").text(e.data.success);
            $timeout(function(){
                location.reload(); 
            },2000);
        }else{
            $(".statusMsg").text(e.data.error);
        }
    }, function error(error) {
        $scope.recordErrors(error);
    });
}else {
    $scope.submitted = true;
}
};


$scope.showCategoryDetails = function(id){
    $("#SubCategorymodalForm").modal('show');
     $http.get(url+'products/'+id, $scope.category).then(function success(data) {
        $scope.subcategories = data.data;       
    }, function error(error) {
        $scope.recordErrors(error);
    });
}

});



</script>
@endsection

